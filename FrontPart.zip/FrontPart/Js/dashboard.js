// ==============================
// Create Map
// ==============================
alert("dashboard.js loaded");
var map = L.map('map').setView([12.9716, 77.5946], 7);

// OpenStreetMap

L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png',{

    attribution:'© OpenStreetMap'

}).addTo(map);

// =================================
// Bus Route
// Bengaluru -> Mysuru
// =================================

const route=[

[12.9716,77.5946],
[12.85,77.40],
[12.70,77.20],
[12.55,77.05],
[12.40,76.90],
[12.30,76.75],
[12.2958,76.6394]

];

// Bus Marker

const bus=L.marker(route[0]).addTo(map);

let index=0;

// Animate Bus

setInterval(()=>{

    index++;

    if(index>=route.length){

        index=0;

    }

    bus.setLatLng(route[index]);

},1000);

// ================================
// Load Dashboard Data
// ================================

fetch("http://localhost:8080/api/dashboard")

.then(response=>response.json())

.then(data=>{

document.getElementById("users").innerHTML=data.totalUsers;

document.getElementById("buses").innerHTML=data.totalBuses;

document.getElementById("alerts").innerHTML=data.matchedAlerts;

document.getElementById("notifications").innerHTML=data.totalNotifications;

});


// =========================
// Search Bus
// =========================

async function searchBus() {

    const source = prompt("Enter Source");

    const destination = prompt("Enter Destination");

    if (!source || !destination) return;

    const response = await fetch(
        `http://localhost:8080/api/buses/search?source=${source}&destination=${destination}`
    );

    const data = await response.json();

    document.getElementById("result").innerHTML =
        "<pre>" + JSON.stringify(data, null, 2) + "</pre>";
}

// =========================
// Create Alert
// =========================

async function createAlert() {

    const source = prompt("Enter Source");

    const destination = prompt("Enter Destination");

    const busType = prompt("Enter Bus Type (AC, NON_AC, VOLVO)");

    const response = await fetch("http://localhost:8080/api/alerts", {

        method: "POST",

        headers: {
            "Content-Type": "application/json"
        },

        body: JSON.stringify({

            userId: 1,

            source: source,

            destination: destination,

            busType: busType

        })

    });

    if (response.ok) {

        alert("Alert Created Successfully");

    } else {

        alert("Failed to Create Alert");

    }
}

// =========================
// Notifications
// =========================

async function loadNotifications() {

    const response = await fetch(
        "http://localhost:8080/api/notifications/user/1"
    );

    const data = await response.json();

    document.getElementById("result").innerHTML =
        "<pre>" + JSON.stringify(data, null, 2) + "</pre>";
}

// =========================
// Welcome User
// =========================

const username = localStorage.getItem("username");

if (username) {

    document.getElementById("welcomeUser").innerHTML =
        "👋 Welcome, " + username;

}

// =========================
// Logout
// =========================

function logout() {

    localStorage.clear();

    alert("Logged Out Successfully");

    window.location.href = "login.html";

}